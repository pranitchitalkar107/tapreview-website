// Add your WhatsApp number with country code, without + or spaces, to receive order requests.
const WHATSAPP_NUMBER = "91XXXXXXXXXX";
const $ = (id) => document.getElementById(id);
let selectedLogo = "";

function updatePreview() {
  const business = $("business").value.trim() || "Your Business";
  $("previewBusiness").textContent = business;
  $("previewMessage").textContent = $("message").value.trim() || "Enjoyed your visit?";
  $("cardPreview").className = "preview-card " + $("design").value;
  $("cardPreview").style.setProperty("--accent", $("accent").value);
  $("previewDestination").textContent = $("destination").textContent;
  $("destination").textContent = $("review").value.trim() ? "Destination: " + $("review").value.trim() : "Destination: not added yet";
  const box = $("qrcode");
  box.innerHTML = "";
  const url = $("review").value.trim();
  if (url && /^https:\/\//i.test(url) && window.QRCode) {
    new QRCode(box, {text:url, width:80, height:80, correctLevel:QRCode.CorrectLevel.M});
  } else {
    box.innerHTML = '<div class="qr-empty">QR PREVIEW</div>';
  }
}
["business","message","review","design","accent"].forEach(id => $(id).addEventListener("input", updatePreview));
$("logo").addEventListener("change", (event) => {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    $("previewLogo").innerHTML = '<img alt="Business logo" style="max-width:90px;max-height:30px;object-fit:contain" src="' + reader.result + '">';
  };
  reader.readAsDataURL(file);
});
$("orderForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const review = $("review").value.trim();
  if (!/^https:\/\//i.test(review)) {
    $("status").textContent = "Please enter a valid Google review link starting with https://";
    return;
  }
  const mobile = $("mobile").value.trim();
  if (!/^\d{10}$/.test(mobile)) {
    $("status").textContent = "Please enter a valid 10-digit mobile number.";
    return;
  }
  const details = [
    "TapReview order request",
    "Business: " + $("business").value.trim(),
    "Google review URL: " + review,
    "Message: " + $("message").value.trim(),
    "Design: " + $("design").value,
    "Accent: " + $("accent").value,
    "Product: " + $("product").value,
    "Quantity: " + $("quantity").value,
    "Customer: " + $("name").value.trim(),
    "Mobile: " + mobile,
    "Delivery address: " + $("address").value.trim()
  ].join("\n");
  if (WHATSAPP_NUMBER === "91XXXXXXXXXX") {
    $("status").textContent = "Your details are valid. To send orders, replace WHATSAPP_NUMBER in script.js with your business WhatsApp number.";
    return;
  }
  const url = "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(details);
  window.open(url, "_blank", "noopener");
  $("status").textContent = "Your order message is ready in WhatsApp. Please review and send it to complete your request.";
});
updatePreview();
